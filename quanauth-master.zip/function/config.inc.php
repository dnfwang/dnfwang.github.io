<?php
$G['db']['server'] = 'localhost';
$G['db']['user'] = 'root';
$G['db']['pass'] = '';
$G['db']['dbname'] = 'wenquan_auth';

//error_reporting(E_ALL);
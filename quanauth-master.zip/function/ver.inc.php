<?php
/**
 * Created by PhpStorm.
 * User: 温泉
 * Date: 2018/8/20
 * Time: 0:58
 */

$G['siteinfo']['ver'] = '12.1';
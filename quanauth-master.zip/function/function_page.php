<?php
/**
 * Created by PhpStorm.
 * User: caidi
 * Date: 2017-10-18
 * Time: 22:28
 */
function show_page_404()
{
    die('404 您访问的页面不存在！');
}
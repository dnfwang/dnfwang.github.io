<?php
/**
 * Created by PhpStorm.
 * User: 80071
 * Date: 2018/10/1
 * Time: 20:25
 */

include "function_core.php";
include 'VerificationCode.class.php';
//error_reporting(E_ALL);

Verification::loadcode();
